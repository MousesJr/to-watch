console.log("main");
const cadastrar= document.getElementById("cadastrar");
cadastrar.addEventListener('click',
function Cadastrar(){
  console.log("test");
  var tags = document.getElementById("tags").value;
  var serie = {
    nome: document.getElementById("nome").value,
    temporadas: document.getElementById("n_temporadas").value,
    tags: tags.split('#')
  }
  document.getElementById("form").reset;
  localStorage['series'] = JSON.stringify(serie);
  return serie;
});
